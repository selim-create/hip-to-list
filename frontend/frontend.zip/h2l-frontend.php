<?php
/**
 * Frontend Yönetimi: Hibrit Yükleme ve Varlık Yönetimi
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Görevler sayfası mı? Tek yerden kontrol
 */
if ( ! function_exists( 'h2l_is_tasks_page' ) ) {
    function h2l_is_tasks_page() {
        // is_page koşulları: hem slug, hem de query_var yedeği
        if ( is_page( 'gorevler') ) {
            return true;
        }

        $pagename = get_query_var( 'pagename', '' );
        if ( $pagename && $pagename === 'gorevler' ) {
            return true;
        }

        return false;
    }
}

/**
 * 1. Şablon Yönlendirme
 */
if ( ! function_exists( 'h2l_force_app_template' ) ) {
    add_filter( 'template_include', 'h2l_force_app_template', 999 );
    function h2l_force_app_template( $template ) {
        if ( h2l_is_tasks_page() ) {
            $new_template = plugin_dir_path( __FILE__ ) . 'templates/h2l-page-template.php';
            if ( file_exists( $new_template ) ) {
                return $new_template;
            }
        }
        return $template;
    }
}

/**
 * 2. İçerik Değiştirme (Yedek)
 */
if ( ! function_exists( 'h2l_force_app_content' ) ) {
    add_filter( 'the_content', 'h2l_force_app_content', 9999 );
    function h2l_force_app_content( $content ) {
        if ( h2l_is_tasks_page() ) {
            return '<div id="h2l-app-container"><div id="h2l-frontend-app"><div class="h2l-loading"><i class="fa-solid fa-circle-notch fa-spin"></i> Yükleniyor...</div></div></div>';
        }
        return $content;
    }
}

/**
 * 3. Varlıkları Yükle
 */
if ( ! function_exists( 'h2l_enqueue_frontend_assets' ) ) {
    add_action( 'wp_enqueue_scripts', 'h2l_enqueue_frontend_assets' );
    function h2l_enqueue_frontend_assets() {

        if ( ! h2l_is_tasks_page() ) {
            return;
        }

        // CSS
        wp_enqueue_style(
            'font-awesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
            array(),
            '6.4.0'
        );

        wp_enqueue_style(
            'h2l-main-css',
            H2L_URL . 'frontend/assets/frontend.css',
            array(),
            filemtime( H2L_PATH . 'frontend/assets/frontend.css' ) // H2L_PATH tanımlıysa daha iyi cache-bust
        );

        wp_enqueue_style(
            'h2l-detail-css',
            H2L_URL . 'frontend/assets/project-detail.css',
            array( 'h2l-main-css' ),
            filemtime( H2L_PATH . 'frontend/assets/project-detail.css' )
        );

        // JS
        wp_enqueue_script(
            'h2l-detail-js',
            H2L_URL . 'frontend/assets/project-detail.js',
            array( 'wp-element' ),
            filemtime( H2L_PATH . 'frontend/assets/project-detail.js' ),
            true
        );

        wp_enqueue_script(
            'h2l-frontend-js',
            H2L_URL . 'frontend/assets/frontend.js',
            array( 'wp-element', 'wp-api-fetch', 'jquery', 'h2l-detail-js' ),
            filemtime( H2L_PATH . 'frontend/assets/frontend.js' ),
            true
        );

        // Kullanıcı verisini sadeleştir
        $current_user = wp_get_current_user();
        $user_data    = array(
            'id'    => (int) $current_user->ID,
            'name'  => (string) $current_user->display_name,
            'email' => (string) $current_user->user_email,
        );

        // ltrim / esc_url_raw / null problemlerine karşı her şeyi stringe çeviriyoruz
        $rest_root = (string) rest_url();
        $base_url  = (string) site_url( '/gorevler' );

        wp_localize_script(
            'h2l-frontend-js',
            'h2lFrontendSettings',
            array(
                'root'        => esc_url_raw( $rest_root ),
                'nonce'       => wp_create_nonce( 'wp_rest' ),
                'base_url'    => esc_url_raw( $base_url ),
                'currentUser' => $user_data,
            )
        );
    }
}
