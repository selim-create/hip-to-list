(function(wp) {
    const { createElement: el, useState } = wp.element;
    window.H2L = window.H2L || {};

    const Icon = ({ name, className = "", onClick, style }) => 
        el('i', { className: `fa-solid fa-${name} ${className}`, onClick, style });

    const Avatar = ({ userId, users, size = 24 }) => { /* ...Basitleştirilmiş... */ return el('div',{className:'h2l-avatar', style:{width:size,height:size, background:'#ccc', borderRadius:'50%'}}); };

    // --- TASK DETAIL MODAL (POPUP) ---
    const TaskDetailModal = ({ task, onClose, onUpdate, users, projects, sections }) => {
        const [title, setTitle] = useState(task.title);
        const [desc, setDesc] = useState(task.content || '');

        const handleSave = () => {
            if(title !== task.title || desc !== task.content) {
                onUpdate(task.id, { title, content: desc });
            }
        };

        return el('div', { className: 'h2l-overlay', onClick: onClose },
            el('div', { className: 'h2l-modal large', onClick: e => e.stopPropagation() },
                el('div', { className: 'h2l-task-modal-content' },
                    // Sol Taraf
                    el('div', { className: 'h2l-tm-main' },
                        el('div', { className: 'h2l-tm-header' },
                            el('div', { className: `h2l-task-check p${task.priority}`, onClick: () => onUpdate(task.id, { status: task.status==='completed'?'open':'completed' }) }, 
                                task.status==='completed' && el(Icon, {name:'check'})
                            ),
                            el('textarea', { 
                                className: 'h2l-tm-title-input', value: title, 
                                onChange: e => setTitle(e.target.value), onBlur: handleSave, rows: 1
                            })
                        ),
                        el('textarea', { 
                            className: 'h2l-tm-desc-input', placeholder: 'Açıklama ekle...', 
                            value: desc, onChange: e => setDesc(e.target.value), onBlur: handleSave 
                        }),
                        el('div', { className: 'h2l-tm-section' },
                            el('h4', null, el(Icon, {name:'list-check'}), ' Alt Görevler'),
                            el('button', { className: 'h2l-btn-text' }, '+ Alt görev ekle')
                        ),
                        el('div', { className: 'h2l-comments-section' },
                            el('h4', null, 'Yorumlar'),
                            el('div', { className: 'h2l-comment-box' },
                                el('input', { className:'h2l-comment-input', placeholder:'Yorum yaz...' })
                            )
                        )
                    ),
                    // Sağ Taraf
                    el('div', { className: 'h2l-tm-sidebar' },
                        el('div', { style:{textAlign:'right', marginBottom:20} }, el(Icon, { name: 'xmark', className: 'h2l-close-icon', onClick: onClose })),
                        el('div', { className: 'h2l-prop-group' },
                            el('span', { className: 'h2l-prop-label' }, 'Atanan'),
                            el('div', { className: 'h2l-prop-value' }, el(Icon,{name:'user'}), 'Kişi Ata')
                        ),
                        el('div', { className: 'h2l-prop-group' },
                            el('span', { className: 'h2l-prop-label' }, 'Tarih'),
                            el('div', { className: 'h2l-prop-value' }, el(Icon,{name:'calendar'}), task.date_display || 'Tarih Ekle')
                        ),
                        el('div', { className: 'h2l-prop-group' },
                            el('span', { className: 'h2l-prop-label' }, 'Öncelik'),
                            el('div', { className: 'h2l-prop-value' }, el(Icon,{name:'flag'}), `P${task.priority}`)
                        )
                    )
                )
            )
        );
    };

    // --- QUICK ADD ---
    const QuickAdd = ({ sectionId, onAdd }) => {
        const [isEditing, setIsEditing] = useState(false);
        const [title, setTitle] = useState('');
        
        const handleSubmit = (e) => {
            e.preventDefault();
            if(title.trim()) { onAdd({ title, sectionId }); setTitle(''); setIsEditing(false); }
        };

        if (!isEditing) {
            return el('div', { className: 'h2l-quick-add-row' },
                el('div', { className: 'h2l-quick-btn', onClick: () => setIsEditing(true) },
                    el('span', { className: 'plus-icon' }, el(Icon, { name: 'plus' })), 'Görev ekle'
                )
            );
        }

        return el('form', { className: 'h2l-quick-form', onSubmit: handleSubmit },
            el('input', { 
                className: 'h2l-quick-input', placeholder: 'Görevin adı ne?', autoFocus: true,
                value: title, onChange: e => setTitle(e.target.value) 
            }),
            el('div', { className: 'h2l-quick-actions' },
                el('div', { className: 'h2l-quick-props' }, 
                    el('span', { className: 'h2l-prop-tag' }, el(Icon,{name:'calendar'}), 'Bugün')
                ),
                el('div', { style:{display:'flex', gap:10} },
                    el('button', { type:'button', className: 'h2l-btn', onClick: () => setIsEditing(false) }, 'İptal'),
                    el('button', { type:'submit', className: 'h2l-btn primary', disabled: !title.trim() }, 'Ekle')
                )
            )
        );
    };

    // --- LIST VIEW ---
    const ListView = ({ tasks, sections, onUpdateTask, onDeleteTask, onAddTask, onTaskClick }) => {
        const rootTasks = tasks.filter(t => !t.sectionId || t.sectionId == 0);
        
        const TaskRow = ({ task }) => el('div', { className: 'h2l-task-row', onClick: () => onTaskClick(task) },
            el('div', { 
                className: `h2l-task-check p${task.priority} ${task.status === 'completed' ? 'completed' : ''}`, 
                onClick: (e) => { e.stopPropagation(); onUpdateTask(task.id, { status: task.status === 'completed' ? 'open' : 'completed' }); } 
            }, el(Icon, { name: 'check' })),
            el('div', { className: 'h2l-task-content' },
                el('div', { className: `h2l-task-title ${task.status === 'completed' ? 'completed' : ''}` }, task.title),
                el('div', { className: 'h2l-task-meta' },
                    task.date_display && el('span', { className: `h2l-task-date` }, el(Icon, {name:'calendar'}), task.date_display)
                )
            ),
            el('div', { className: 'h2l-task-actions' },
                el('button', { className: 'h2l-icon-btn danger', onClick: (e) => { e.stopPropagation(); if(confirm('Sil?')) onDeleteTask(task.id); } }, el(Icon, { name: 'trash' }))
            )
        );

        return el('div', { className: 'h2l-list-view' },
            rootTasks.length > 0 && el('div', { className: 'h2l-section' },
                rootTasks.map(t => el(TaskRow, { key: t.id, task: t }))
            ),
            sections.map(s => {
                const sTasks = tasks.filter(t => parseInt(t.sectionId) === parseInt(s.id));
                return el('div', { key: s.id, className: 'h2l-section' },
                    el('div', { className: 'h2l-section-head' }, 
                        s.name, el('span', { className: 'h2l-section-count' }, sTasks.length)
                    ),
                    sTasks.map(t => el(TaskRow, { key: t.id, task: t })),
                    el(QuickAdd, { sectionId: s.id, onAdd: onAddTask })
                );
            }),
            el(QuickAdd, { sectionId: 0, onAdd: onAddTask })
        );
    };

    // --- BOARD VIEW ---
    const BoardView = ({ tasks, sections, onUpdateTask }) => {
        const columns = sections.length > 0 
            ? sections.map(s => ({ id: s.id, title: s.name, type: 'section' }))
            : [{ id: 'open', title: 'Başlanmadı', type: 'status' }, { id: 'in_progress', title: 'Sürüyor', type: 'status' }, { id: 'completed', title: 'Tamamlandı', type: 'status' }];

        return el('div', { className: 'h2l-board-container' },
            columns.map(col => {
                const colTasks = col.type === 'section' 
                    ? tasks.filter(t => parseInt(t.sectionId) === parseInt(col.id))
                    : tasks.filter(t => t.status === col.id);

                return el('div', { key: col.id, className: 'h2l-board-col' },
                    el('div', { className: 'h2l-col-header' }, col.title, el('span', {style:{color:'#999', fontSize:12}}, colTasks.length)),
                    el('div', { className: 'h2l-col-scroll' },
                        colTasks.map(t => el('div', { key: t.id, className: 'h2l-board-card' },
                            el('div', { className: 'h2l-card-content' }, t.title),
                            el('div', { className: 'h2l-card-meta' },
                                t.date_display ? el('span', null, el(Icon,{name:'calendar'}), ' ', t.date_display) : el('span')
                            )
                        ))
                    )
                );
            })
        );
    };

    // --- ANA BİLEŞEN (EXPORT) ---
    window.H2L.ProjectDetail = ({ project, tasks, sections, users, onAddTask, onUpdateTask, onDeleteTask, navigate }) => {
        const [viewMode, setViewMode] = useState(project.view_type || 'list');
        const [selectedTask, setSelectedTask] = useState(null);

        if (!project) return null;

        return el('div', { className: 'h2l-project-detail-wrapper' },
            el('div', { className: 'h2l-detail-head' },
                el('div', { className: 'h2l-head-left' },
                    el('button', { className: 'h2l-back-link', onClick: () => navigate('') }, el(Icon,{name:'arrow-left'})),
                    el('h1', null, 
                        el('span', { style: { color: project.color, marginRight: 10, fontSize: 24 } }, '#'), 
                        project.title
                    ),
                    el('div', { className: 'h2l-head-meta' }, `${tasks.length} görev`)
                ),
                el('div', { className: 'h2l-view-toggle' },
                    el('button', { className: viewMode==='list'?'active':'', onClick:()=>setViewMode('list') }, el(Icon,{name:'list'}), 'Liste'),
                    el('button', { className: viewMode==='board'?'active':'', onClick:()=>setViewMode('board') }, el(Icon,{name:'table-columns'}), 'Pano')
                )
            ),
            
            viewMode === 'list' 
                ? el(ListView, { tasks, sections, onUpdateTask, onDeleteTask, onAddTask: (opts) => onAddTask({ projectId: project.id, ...opts }), onTaskClick: setSelectedTask })
                : el(BoardView, { tasks, sections, onUpdateTask }),
            
            selectedTask && el(TaskDetailModal, { 
                task: selectedTask, 
                onClose: () => setSelectedTask(null),
                onUpdate: (id, d) => { onUpdateTask(id, d); setSelectedTask({...selectedTask, ...d}); },
                users, projects: [project], sections // Basitleştirilmiş veri
            })
        );
    };

})(window.wp);